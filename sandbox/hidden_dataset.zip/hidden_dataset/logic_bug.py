def count_down(n):
    while n > 0:
        print(n)
        n += 1 # Bug : n augmente au lieu de diminuer