def calculate_sum(a, b)  # Manque le deux-points
    return a + b