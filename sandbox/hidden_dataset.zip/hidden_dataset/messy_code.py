x = 10
# Variable mal nommée, pas de docstring, logique inutile
def f(z):
    if z > 0:
        if z < 100:
            return True
    return False